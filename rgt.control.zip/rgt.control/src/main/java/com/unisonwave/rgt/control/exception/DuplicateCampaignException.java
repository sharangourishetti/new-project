package com.unisonwave.rgt.control.exception;


public class DuplicateCampaignException extends RuntimeException {
    
	public DuplicateCampaignException(String message) {
        super(message);
    }
}


